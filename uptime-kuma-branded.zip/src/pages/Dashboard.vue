<template>
  <div style="background-color: var(--background); color: var(--text-color); min-height: 100vh; padding: 1rem;">
    <h1 style="color: var(--primary); font-size: 2rem;">داشبورد مانیتورینگ برند شما</h1>
    <p>این نسخه سفارشی‌شده با تم قرمز/مشکی و قرمز/سفید است.</p>
  </div>
</template>

<script>
export default {
  name: "Dashboard"
}
</script>
